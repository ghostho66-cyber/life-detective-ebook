# 生活小偵探實作計劃

Goal: 八項教案活動全部可操作、可分享的電子書。
Architecture: HTML/CSS/ES modules，SVG 圖像，Pointer Events 畫布，localStorage 匿名進度。
Spec: docs/design.md

- [x] 核心遊戲邏輯：選項、記憶集合、句子校驗、摹寫覆蓋評估；先驗證反例。
- [x] 電子書與所有活動：章節目錄、學習／練習、難度、求助、回饋、導師指引與設定。
- [x] 跨裝置分享：QR、複製連結及分享 API；公開部署不含個人資料。
- [x] 驗證：Node 測試、桌面與手機瀏覽器互動、上線狀態。

Review focus: 重複點擊不可重複計分；換頁取消計時；錯誤答案可重試；觸控縮放保留畫線；本機儲存不可用仍能活動。
