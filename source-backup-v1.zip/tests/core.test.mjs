import test from 'node:test';
import assert from 'node:assert/strict';
let api={}; try {api=await import('../dist/core.js')} catch {}
test('choices always include target exactly once, including small pools',()=>{
  assert.equal(typeof api.makeChoices,'function');
  for(let i=0;i<30;i++){const c=api.makeChoices(['a','b','c','d'],'b',3);assert.equal(c.length,3);assert.equal(c.filter(x=>x==='b').length,1);assert.equal(new Set(c).size,3)}
  assert.equal(api.makeChoices(['a','b'],'a',4).length,2);
});
test('memory requires every target and rejects extra or repeated selections',()=>{
  assert.equal(typeof api.matchesMemory,'function');
  assert.equal(api.matchesMemory(['a','b'],['b','a']),true);
  for(const s of [['a'],['a','a'],['a','b','c']])assert.equal(api.matchesMemory(['a','b'],s),false);
});
test('sentences require correct order and all tokens',()=>{
  assert.equal(typeof api.matchesSentence,'function');
  assert.equal(api.matchesSentence(['我','想','飲水'],['我','想','飲水']),true);
  assert.equal(api.matchesSentence(['我','想','飲水'],['想','我','飲水']),false);
  assert.equal(api.matchesSentence(['我','想','飲水'],['我','想']),false);
});
test('tracing accepts following a line, rejects dots and off-target scribbles',()=>{
  assert.equal(typeof api.traceScore,'function');
  const target=Array.from({length:41},(_,i)=>[100+i*10,200]);
  assert.ok(api.traceScore([target],target,22).passed);
  assert.equal(api.traceScore([[[100,200]]],target,22).passed,false);
  assert.equal(api.traceScore([target.map(([x])=>[x,50])],target,22).passed,false);
  assert.equal(api.traceScore([],target,22).passed,false);
});
test('a second finger cannot replace or end the current drawing stroke',()=>{
  assert.equal(typeof api.createTraceInput,'function');
  const input=api.createTraceInput();
  assert.equal(input.begin(1,[100,200]),true);
  assert.equal(input.begin(2,[400,100]),false);
  assert.equal(input.move(2,[500,100]),false);
  assert.equal(input.end(2),false);
  assert.equal(input.move(1,[150,200]),true);
  assert.equal(input.strokes.length,1);
  assert.deepEqual(input.strokes[0].at(-1),[150,200]);
  assert.equal(input.end(1),true);
  assert.equal(input.move(1,[200,200]),false);
  assert.equal(input.begin(2,[200,200]),true);
  input.clear();assert.equal(input.strokes.length,0);
  assert.equal(input.begin(3,[0,0]),true);
});
